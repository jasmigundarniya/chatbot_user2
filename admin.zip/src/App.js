import React from 'react'
import AdminChat from './AdminChat'

const App = () => {
  return (
    <>
    <AdminChat/>
    </>
  )
}

export default App